#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <assert.h>
#include "memwatch.h"


#define line_ini 10
#define text_ini 40


int len(const char *a);
char lower_case(const char a);
void lowerstring(char* string, int wordrange);
void compare_term(char* term,long totalchar,char*textlist);
void compare_term_list(FILE* listfile, long totalchar,char*textlist);
void compare_term_target_radius(FILE*term,char*target,FILE*checklist, int radius);
void compare_term_target_list_default(char*term,char*target,FILE*checklist);
void compare_term_target(char*term,char*target);



